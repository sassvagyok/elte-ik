import static check.CheckThat.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;
import check.*;

import vehicle.Car;
import vehicle.Size;
import parking.facility.Space;
import parking.facility.Gate;
import parking.ParkingLot;

public class GateTest {
    @Test
    public void testFindAnyAvailableSpaceForCar() {
        ParkingLot parkingLot = new ParkingLot(5, 10);
        Space[][] floorPlan = parkingLot.getFloorPlan();
        Gate gate = new Gate(parkingLot);
        Car smallCar = new Car("ASD-000", Size.SMALL, 0);
        Car largeCar = new Car("ASD-001", Size.LARGE, 3);

        assertEquals(floorPlan[0][0], gate.findAnyAvailableSpaceForCar(smallCar));
        assertEquals(floorPlan[0][0], gate.findAnyAvailableSpaceForCar(largeCar));
    }

    // @Test
    // public void testGetMin() {
    //     assertEquals(34, new Time(12, 34).getMin());
    // }

    // @Test
    // public void testSetHour() {
    //     Time time = new Time(0, 0);
    //     time.setHour(12);
    //     assertEquals(12, time.getHour());
    // }

    // @Test
    // public void testSetMin() {
    //     Time time = new Time(0, 0);
    //     time.setMin(34);
    //     assertEquals(34, time.getMin());
    // }

    // @ParameterizedTest(name = "{2}:{3} vs {4}:{5} ⟹ {0}:{1}")
    // @CsvSource(textBlock = """
    //     01, 02,   01, 02, 12, 34
    //     01, 59,   01, 59, 12, 34
    //     12, 34,   23, 59, 12, 34
    // """)
    // @DisableIfHasBadStructure
    // public void testEarlier(int expectedHour, int expectedMin, int hour1, int min1, int hour2, int min2) {
    //     Time time1 = new Time(hour1, min1);
    //     Time time2 = new Time(hour2, min2);

    //     assertEquals(expectedHour, time1.getEarlier(time2).getHour());
    //     assertEquals(expectedMin, time1.getEarlier(time2).getMin());

    //     assertEquals(expectedHour, time2.getEarlier(time1).getHour());
    //     assertEquals(expectedMin, time2.getEarlier(time1).getMin());
    // }
}
