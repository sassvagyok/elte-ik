﻿namespace Szervizeles;

public class Program
{
    static void Main()
    {
        
    }
}