/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package yogibear;

/**
 *
 * @author matep
 */
public class YogiBear {

    public static void main(String[] args) {
        YogiBearGUI gui = new YogiBearGUI();
    }
    
}
